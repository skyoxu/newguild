# Encoding Fixture (Bad Case)

本文件故意包含替代符，用于触发编码扫描器：�

注意：该文件仅用于测试扫描脚本，不应影响文档阅读。
